// CS2 Capture The Flag — a CounterStrikeSharp plugin
// Two flags (T = red, CT = blue). Steal the enemy flag, bring it to your own
// base while your flag is home, score a capture. First to CaptureLimit wins.

using System.Drawing;
using System.Numerics;
using System.Text.Json;
using System.Text.Json.Serialization;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Admin;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Entities.Constants;
using CounterStrikeSharp.API.Modules.Timers;
using CounterStrikeSharp.API.Modules.Utils;
using Microsoft.Extensions.Logging;
using CsVector = CounterStrikeSharp.API.Modules.Utils.Vector;

namespace CS2CTF;

public class CTFConfig : BasePluginConfig
{
    [JsonPropertyName("CaptureLimit")] public int CaptureLimit { get; set; } = 3;
    [JsonPropertyName("MatchMinutes")] public float MatchMinutes { get; set; } = 15f;
    [JsonPropertyName("RespawnSeconds")] public float RespawnSeconds { get; set; } = 8f;
    [JsonPropertyName("PickupRadius")] public float PickupRadius { get; set; } = 60f;
    [JsonPropertyName("CaptureRadius")] public float CaptureRadius { get; set; } = 90f;
    [JsonPropertyName("FlagReturnSeconds")] public float FlagReturnSeconds { get; set; } = 30f;
    [JsonPropertyName("FlagModel")] public string FlagModel { get; set; } = "models/chicken/chicken.vmdl";
    [JsonPropertyName("CarryHeight")] public float CarryHeight { get; set; } = 82f;
    [JsonPropertyName("SpinFlags")] public bool SpinFlags { get; set; } = true;
    [JsonPropertyName("EndDelaySeconds")] public float EndDelaySeconds { get; set; } = 8f;
    [JsonPropertyName("AlertSound")] public string AlertSound { get; set; } = "UIPanorama.popup_accept_match_beep";
    [JsonPropertyName("AlertBeeps")] public int AlertBeeps { get; set; } = 3;
    [JsonPropertyName("BeepGapSeconds")] public float BeepGapSeconds { get; set; } = 0.3f;
    [JsonPropertyName("FlagScale")] public float FlagScale { get; set; } = 2.0f;
    [JsonPropertyName("Beacon")] public bool Beacon { get; set; } = true;
    [JsonPropertyName("BeaconHeight")] public float BeaconHeight { get; set; } = 500f;
    [JsonPropertyName("BeaconWidth")] public float BeaconWidth { get; set; } = 6f;
    [JsonPropertyName("KnifeOnlyCarrier")] public bool KnifeOnlyCarrier { get; set; } = true;
    [JsonPropertyName("DropWithUseKey")] public bool DropWithUseKey { get; set; } = true;
    [JsonPropertyName("RepickupCooldownSeconds")] public float RepickupCooldownSeconds { get; set; } = 2f;
    [JsonPropertyName("ShieldsEnabled")] public bool ShieldsEnabled { get; set; } = true;
    [JsonPropertyName("ShieldAmount")] public int ShieldAmount { get; set; } = 50;
    [JsonPropertyName("ShieldRechargeDelaySeconds")] public float ShieldRechargeDelaySeconds { get; set; } = 6f;
    [JsonPropertyName("ShieldRechargePerSecond")] public float ShieldRechargePerSecond { get; set; } = 25f;
    [JsonPropertyName("ShowShieldText")] public bool ShowShieldText { get; set; } = true;
    [JsonPropertyName("AmmoMode")] public string AmmoMode { get; set; } = "endless";   // endless | double | normal
    [JsonPropertyName("CarrierSpeed")] public float CarrierSpeed { get; set; } = 0.85f;   // 1.0 = normal, 0.85 = 15% slower
    [JsonPropertyName("ShieldTextStyle")] public string ShieldTextStyle { get; set; } = "html"; // html | alert | center
}

public enum FlagState { Home, Carried, Dropped }

public class Flag
{
    public CsTeam Owner;
    public Vector3 Home;
    public Vector3 Position;         // feet-level position (home, dropped spot, or carrier's feet)
    public FlagState State = FlagState.Home;
    public int CarrierSlot = -1;
    public float DroppedAt;
    public CDynamicProp? Prop;
    public CBeam? Beam;              // pillar of light above the flag

    // reused to avoid allocating native vectors every tick
    public CsVector DrawPos = new(0, 0, 0);
    public QAngle DrawAng = new(0, 0, 0);
}

public class BaseFile
{
    public float[]? T { get; set; }
    public float[]? CT { get; set; }
}

public class CTFPlugin : BasePlugin, IPluginConfig<CTFConfig>
{
    public override string ModuleName => "CS2 Capture The Flag";
    public override string ModuleVersion => "0.8.1";
    public override string ModuleAuthor => "Jish Josh";
    public override string ModuleDescription => "Classic two-flag CTF for CS2 community servers";

    public CTFConfig Config { get; set; } = new();
    public void OnConfigParsed(CTFConfig config) => Config = config;

    private const string Prefix = " \x02[\x04CTF\x02]\x01 ";
    private const float AlertHoldSeconds = 3f;

    private readonly Dictionary<CsTeam, Flag> _flags = new();
    private readonly Dictionary<CsTeam, int> _score = new() { [CsTeam.Terrorist] = 0, [CsTeam.CounterTerrorist] = 0 };
    private readonly Dictionary<int, float> _respawnAt = new();   // slot -> time they come back
    private readonly Dictionary<int, float> _alertUntil = new();  // slot -> keep event alert on screen until
    private readonly Dictionary<int, string> _alertText = new();  // slot -> the event alert being shown
    private readonly Dictionary<int, float> _noPickupUntil = new(); // slot -> can't grab a flag until (after dropping one)
    private readonly HashSet<int> _useHeld = new();                // slots holding E last tick (to detect a fresh press)
    private readonly CsVector _zero = new(0, 0, 0);
    private float _matchStart;
    private bool _matchOver;
    private float _yaw;

    // ───────────────────────── lifecycle ─────────────────────────

    public override void Load(bool hotReload)
    {
        RegisterListener<Listeners.OnServerPrecacheResources>(manifest => manifest.AddResource(Config.FlagModel));
        RegisterListener<Listeners.OnTick>(OnTick);
        RegisterListener<Listeners.OnMapStart>(_ =>
        {
            _flags.Clear();
            _respawnAt.Clear();
            _matchOver = false;
            // Apply CTF server settings after the game mode's own configs have run.
            AddTimer(1.0f, ApplyServerSettings);
        });

        if (hotReload)
            Server.NextFrame(StartMatch);
    }

    public override void Unload(bool hotReload) => RemoveProps();

    private void ApplyServerSettings()
    {
        // The on-screen round clock is the match clock, so keep it in sync with MatchMinutes (CS2 max is 60).
        var minutes = Config.MatchMinutes > 0 ? Math.Clamp(Config.MatchMinutes, 1f, 60f) : 60f;
        Server.ExecuteCommand(
            "exec ctf; " +
            $"mp_roundtime {minutes}; mp_roundtime_defuse {minutes}; mp_roundtime_hostage {minutes}; " +
            "mp_respawn_on_death_t 0; mp_respawn_on_death_ct 0");
    }

    [GameEventHandler]
    public HookResult OnRoundStart(EventRoundStart @event, GameEventInfo info)
    {
        // Round restart wipes spawned props, so (re)build everything each round.
        Server.NextFrame(StartMatch);
        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnFreezeEnd(EventRoundFreezeEnd @event, GameEventInfo info)
    {
        // The round clock starts counting after freeze time — start ours at the same moment.
        _matchStart = Server.CurrentTime;
        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnPlayerDeath(EventPlayerDeath @event, GameEventInfo info)
    {
        var victim = @event.Userid;
        if (victim == null || !victim.IsValid) return HookResult.Continue;

        var carried = FlagCarriedBy(victim.Slot);
        if (carried != null)
        {
            var killer = @event.Attacker;
            if (killer != null && killer.IsValid && killer.Slot != victim.Slot)
                Server.PrintToChatAll($"{Prefix}{TeamColor(killer.Team)}{killer.PlayerName}\x01 took down the flag carrier!");
            Drop(carried, victim.PlayerName);
        }

        _shields.Remove(victim.Slot);
        ScheduleRespawn(victim, Config.RespawnSeconds);
        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnPlayerTeam(EventPlayerTeam @event, GameEventInfo info)
    {
        // Players who join (or switch to) a team mid-match would otherwise sit dead until the match ends.
        var p = @event.Userid;
        if (p != null && p.IsValid && !@event.Disconnect && (@event.Team == 2 || @event.Team == 3))
            ScheduleRespawn(p, 2f);
        return HookResult.Continue;
    }

    // ───────────────────────── Halo-style shields ─────────────────────────
    // Players get ShieldAmount extra HP on top of their 100 health. Damage eats the
    // shield first. After ShieldRechargeDelaySeconds without being hurt, the shield
    // (not health) refills. The HP number on the HUD shows health + shield, and a
    // shield bar shows in the centre of the screen while it's down or recharging.

    private sealed class ShieldState { public float Shield; public int Hp; public float LastHurt; public bool AnnouncedBroken; }
    private readonly Dictionary<int, ShieldState> _shields = new();
    private float _nextShieldTick;

    [GameEventHandler]
    public HookResult OnPlayerSpawn(EventPlayerSpawn @event, GameEventInfo info)
    {
        var p = @event.Userid;
        if (p == null || !p.IsValid || !Config.ShieldsEnabled) return HookResult.Continue;
        var slot = p.Slot;

        // let the game finish setting up the pawn, then add the shield on top
        AddTimer(0.1f, () =>
        {
            var pl = Utilities.GetPlayerFromSlot(slot);
            var pawn = pl?.PlayerPawn.Value;
            if (pl == null || !pl.IsValid || pawn == null || !pawn.IsValid || !pl.PawnIsAlive) return;

            var hp = Math.Max(1, pawn.Health);
            _shields[slot] = new ShieldState { Shield = Config.ShieldAmount, Hp = hp, LastHurt = -999f };
            SetPawnHealth(pawn, hp + Config.ShieldAmount, hp + Config.ShieldAmount);
        });
        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnPlayerHurt(EventPlayerHurt @event, GameEventInfo info)
    {
        var p = @event.Userid;
        if (p == null || !p.IsValid || !Config.ShieldsEnabled) return HookResult.Continue;
        if (!_shields.TryGetValue(p.Slot, out var s)) return HookResult.Continue;

        // Work out how the hit split between shield and health
        var remaining = Math.Max(0, @event.Health);
        var damage = Math.Max(0, (int)Math.Round(s.Hp + s.Shield) - remaining);
        var hadShield = s.Shield > 0;
        s.Shield = Math.Max(0, s.Shield - damage);
        s.Hp = Math.Max(0, remaining - (int)Math.Round(s.Shield));
        s.LastHurt = Server.CurrentTime;

        if (hadShield && s.Shield <= 0 && remaining > 0 && !s.AnnouncedBroken && !p.IsBot)
        {
            s.AnnouncedBroken = true;
            if (Config.ShieldTextStyle.ToLowerInvariant() != "html")
                Alert(p, "SHIELD DOWN!", sound: false, hold: 1.5f);
        }
        return HookResult.Continue;
    }

    private void RechargeShields(float now)
    {
        if (!Config.ShieldsEnabled || now < _nextShieldTick) return;
        const float step = 0.1f;
        _nextShieldTick = now + step;

        foreach (var (slot, s) in _shields)
        {
            if (s.Shield >= Config.ShieldAmount) continue;
            if (now - s.LastHurt < Config.ShieldRechargeDelaySeconds) continue;

            var p = Utilities.GetPlayerFromSlot(slot);
            var pawn = p?.PlayerPawn.Value;
            if (p == null || !p.IsValid || !p.PawnIsAlive || pawn == null || !pawn.IsValid) continue;

            // pick up any healing the game did on its own
            s.Hp = Math.Max(1, pawn.Health - (int)Math.Round(s.Shield));
            s.Shield = Math.Min(Config.ShieldAmount, s.Shield + Config.ShieldRechargePerSecond * step);
            s.AnnouncedBroken = false;
            SetPawnHealth(pawn, s.Hp + (int)Math.Round(s.Shield), 100 + Config.ShieldAmount);
        }
    }

    private static void SetPawnHealth(CCSPlayerPawn pawn, int health, int max)
    {
        pawn.MaxHealth = max;
        pawn.Health = health;
        Utilities.SetStateChanged(pawn, "CBaseEntity", "m_iMaxHealth");
        Utilities.SetStateChanged(pawn, "CBaseEntity", "m_iHealth");
    }

    private string? ShieldHudLine(CCSPlayerController p, float now)
    {
        if (!Config.ShieldsEnabled || !Config.ShowShieldText || !p.PawnIsAlive || !_shields.TryGetValue(p.Slot, out var s)) return null;
        if (s.Shield >= Config.ShieldAmount) return null;

        var pct = (int)Math.Round(100f * s.Shield / Math.Max(1, Config.ShieldAmount));
        var bars = (int)Math.Round(pct / 10f);
        var bar = new string('|', bars) + new string('.', 10 - bars);
        if (now - s.LastHurt < Config.ShieldRechargeDelaySeconds)
            return s.Shield <= 0 ? "SHIELD DOWN" : $"SHIELD [{bar}] {pct}%";
        return $"SHIELD RECHARGING [{bar}] {pct}%";
    }

    private string? ShieldHtml(CCSPlayerController p, float now)
    {
        if (!Config.ShieldsEnabled || !Config.ShowShieldText || !p.PawnIsAlive || !_shields.TryGetValue(p.Slot, out var s)) return null;
        if (s.Shield >= Config.ShieldAmount) return null;

        var pct = (int)Math.Round(100f * s.Shield / Math.Max(1, Config.ShieldAmount));
        var filled = (int)Math.Round(pct / 5f);                       // 20-segment bar
        var down = s.Shield <= 0 && now - s.LastHurt < Config.ShieldRechargeDelaySeconds;
        var label = down ? "<font color='#ff5a4a'>SHIELD DOWN</font>" : "<font color='#4fc3ff'>SHIELD</font>";
        var bar = $"<font color='#4fc3ff'>{new string('|', filled)}</font><font color='#3a3f47'>{new string('|', 20 - filled)}</font>";

        return $"<font class='fontSize-m fontWeight-Bold'>{label} {bar} {pct}%</font>";
    }

    [ConsoleCommand("css_ctf_shieldstyle", "Switch how the shield bar is shown: html, alert or center")]
    [CommandHelper(minArgs: 1, usage: "<html|alert|center>")]
    [RequiresPermissions("@css/root")]
    public void CmdShieldStyle(CCSPlayerController? player, CommandInfo cmd)
    {
        var style = cmd.GetArg(1).ToLowerInvariant();
        if (style != "html" && style != "alert" && style != "center")
        {
            cmd.ReplyToCommand("[CTF] Use: !ctf_shieldstyle html | alert | center");
            return;
        }
        Config.ShieldTextStyle = style;
        cmd.ReplyToCommand($"[CTF] Shield bar style is now '{style}' (until the server restarts - set ShieldTextStyle in CS2CTF.json to keep it).");
    }

    // ───────────────────────── respawning ─────────────────────────

    private void ScheduleRespawn(CCSPlayerController player, float delay)
    {
        var slot = player.Slot;
        var at = Server.CurrentTime + delay;
        _respawnAt[slot] = at;

        AddTimer(delay, () =>
        {
            if (!_respawnAt.TryGetValue(slot, out var due) || Math.Abs(due - at) > 0.01f) return; // superseded
            _respawnAt.Remove(slot);
            if (_matchOver) return;

            var p = Utilities.GetPlayerFromSlot(slot);
            if (p == null || !p.IsValid || p.PawnIsAlive) return;
            if (p.Team != CsTeam.Terrorist && p.Team != CsTeam.CounterTerrorist) return;
            p.Respawn();
        });
    }

    // ───────────────────────── match setup ─────────────────────────

    private void ReleaseAllCarriers()
    {
        foreach (var f in _flags.Values.Where(f => f.State == FlagState.Carried))
        {
            var c = Utilities.GetPlayerFromSlot(f.CarrierSlot);
            if (c != null && c.IsValid && c.PawnIsAlive) SetGunsBlocked(c, false);
        }
    }

    private void StartMatch()
    {
        _ammoBoosted.Clear();
        ReleaseAllCarriers();
        RemoveProps();
        _flags.Clear();
        _respawnAt.Clear();
        _score[CsTeam.Terrorist] = 0;
        _score[CsTeam.CounterTerrorist] = 0;
        PushTeamScores();
        _matchOver = false;
        _matchStart = Server.CurrentTime;

        var saved = LoadBases();
        foreach (var team in new[] { CsTeam.Terrorist, CsTeam.CounterTerrorist })
        {
            var home = SavedBase(saved, team) ?? AverageSpawn(team);
            if (home == null)
            {
                Logger.LogWarning($"[CTF] No base for {team} on {Server.MapName}. Use !ctf_setbase.");
                continue;
            }

            var flag = new Flag { Owner = team, Home = home.Value, Position = home.Value };
            flag.Prop = SpawnFlagProp(team);
            if (Config.Beacon) flag.Beam = SpawnBeacon(team, home.Value);
            _flags[team] = flag;
            MoveProp(flag);
        }

        if (_flags.Count == 2)
            Server.PrintToChatAll($"{Prefix}Capture the Flag! First to \x04{Config.CaptureLimit}\x01 captures wins.");
    }

    private CDynamicProp? SpawnFlagProp(CsTeam team)
    {
        var prop = Utilities.CreateEntityByName<CDynamicProp>("prop_dynamic");
        if (prop == null) return null;

        var color = TeamRgb(team);
        prop.Render = color;
        prop.Glow.GlowColorOverride = color;
        prop.Glow.GlowRange = 5000;
        prop.Glow.GlowRangeMin = 0;
        prop.Glow.GlowTeam = -1;
        prop.Glow.GlowType = 3;

        prop.SetModel(Config.FlagModel);
        prop.DispatchSpawn();
        prop.AcceptInput("DisableCollision");

        if (Math.Abs(Config.FlagScale - 1f) > 0.01f)
        {
            var node = prop.CBodyComponent?.SceneNode;
            if (node != null)
            {
                node.GetSkeletonInstance().Scale = Config.FlagScale;
                Utilities.SetStateChanged(prop, "CBaseEntity", "m_CBodyComponent");
            }
        }
        return prop;
    }

    private CBeam? SpawnBeacon(CsTeam team, Vector3 at)
    {
        var beam = Utilities.CreateEntityByName<CBeam>("beam");
        if (beam == null) return null;

        beam.Render = Color.FromArgb(200, TeamRgb(team));
        beam.Width = Config.BeaconWidth;
        beam.EndWidth = Config.BeaconWidth;
        beam.Teleport(new CsVector(at.X, at.Y, at.Z), new QAngle(0, 0, 0), _zero);
        beam.EndPos.X = at.X;
        beam.EndPos.Y = at.Y;
        beam.EndPos.Z = at.Z + Config.BeaconHeight;
        beam.DispatchSpawn();
        return beam;
    }

    private void RemoveProps()
    {
        foreach (var f in _flags.Values)
        {
            if (f.Prop != null && f.Prop.IsValid) f.Prop.Remove();
            if (f.Beam != null && f.Beam.IsValid) f.Beam.Remove();
        }
    }

    // ───────────────────────── game loop ─────────────────────────

    private void OnTick()
    {
        var now = Server.CurrentTime;
        RechargeShields(now);
        ManageAmmo(now);
        UpdateHud();   // every tick - the HTML panel flickers if it isn't refreshed constantly

        if (_flags.Count < 2 || _matchOver) return;
        if (Config.SpinFlags) _yaw = (_yaw + 2f) % 360f;

        // 1. update flag states / positions
        foreach (var flag in _flags.Values)
        {
            if (flag.State == FlagState.Carried)
            {
                var carrier = Utilities.GetPlayerFromSlot(flag.CarrierSlot);
                var pos = carrier != null && carrier.IsValid && carrier.PawnIsAlive && carrier.Team != flag.Owner
                    ? PawnPos(carrier) : null;

                if (pos == null) Drop(flag, carrier != null && carrier.IsValid ? carrier.PlayerName : "The carrier");
                else
                {
                    flag.Position = pos.Value;
                    SlowCarrier(carrier!);
                }
            }
            else if (flag.State == FlagState.Dropped && now - flag.DroppedAt >= Config.FlagReturnSeconds)
            {
                ReturnHome(flag);
                AnnounceReturn(flag, null);
            }

            MoveProp(flag);
        }

        // 2. player interactions
        foreach (var p in Utilities.GetPlayers())
        {
            if (!p.IsValid || !p.PawnIsAlive || p.IsHLTV) continue;
            if (p.Team != CsTeam.Terrorist && p.Team != CsTeam.CounterTerrorist) continue;
            var pos = PawnPos(p);
            if (pos == null) continue;

            // E (use) pressed this tick while carrying -> drop the flag
            if (UsePressed(p) && Config.DropWithUseKey)
            {
                var held = FlagCarriedBy(p.Slot);
                if (held != null)
                {
                    _noPickupUntil[p.Slot] = now + Config.RepickupCooldownSeconds;
                    Drop(held, p.PlayerName);
                    p.ExecuteClientCommand("slot1");
                    continue;
                }
            }

            foreach (var flag in _flags.Values)
            {
                if (flag.State == FlagState.Carried) continue;
                if (Vector3.Distance(pos.Value, flag.Position) > Config.PickupRadius) continue;

                if (p.Team != flag.Owner)
                {
                    if (_noPickupUntil.TryGetValue(p.Slot, out var until) && now < until) continue;
                    Pickup(flag, p);
                }
                else if (flag.State == FlagState.Dropped)
                {
                    ReturnHome(flag);
                    AnnounceReturn(flag, p);
                }
            }

            // capture: carrying the enemy flag, own flag is home, standing at own base
            var stolen = FlagCarriedBy(p.Slot);
            if (stolen != null && _flags.TryGetValue(p.Team, out var own) && own.State == FlagState.Home
                && Vector3.Distance(pos.Value, own.Home) <= Config.CaptureRadius)
            {
                Capture(p, stolen);
                if (_matchOver) return;
            }
        }

        EnforceKnife(now);

        // 3. time limit
        if (Config.MatchMinutes > 0 && now - _matchStart >= Config.MatchMinutes * 60f)
        {
            var t = _score[CsTeam.Terrorist];
            var ct = _score[CsTeam.CounterTerrorist];
            EndMatch(t == ct ? null : t > ct ? CsTeam.Terrorist : CsTeam.CounterTerrorist, "Time's up!");
        }
    }

    private void MoveProp(Flag flag)
    {
        if (flag.Prop == null || !flag.Prop.IsValid) return;

        var lift = flag.State == FlagState.Carried ? Config.CarryHeight : 4f;
        flag.DrawPos.X = flag.Position.X;
        flag.DrawPos.Y = flag.Position.Y;
        flag.DrawPos.Z = flag.Position.Z + lift;
        flag.DrawAng.Y = _yaw;
        flag.Prop.Teleport(flag.DrawPos, flag.DrawAng, _zero);

        // beacon follows the flag (starts at the flag, shoots straight up)
        if (flag.Beam != null && flag.Beam.IsValid)
        {
            flag.Beam.Teleport(flag.DrawPos, null, _zero);
            flag.Beam.EndPos.X = flag.DrawPos.X;
            flag.Beam.EndPos.Y = flag.DrawPos.Y;
            flag.Beam.EndPos.Z = flag.DrawPos.Z + Config.BeaconHeight;
            Utilities.SetStateChanged(flag.Beam, "CBeam", "m_vecEndPos");
        }
    }

    /// True only on the tick E goes down (not while it's held).
    private bool UsePressed(CCSPlayerController p)
    {
        bool down;
        try { down = (p.Buttons & PlayerButtons.Use) != 0; }
        catch { down = false; }

        var wasDown = _useHeld.Contains(p.Slot);
        if (down) _useHeld.Add(p.Slot); else _useHeld.Remove(p.Slot);
        return down && !wasDown;
    }

    // ───────────────────────── carrier speed / ammo ─────────────────────────

    /// The game eases VelocityModifier back to 1 on its own, so this is re-applied every tick.
    /// Lower values (e.g. the slow from being shot) are left alone.
    private void SlowCarrier(CCSPlayerController p)
    {
        if (Config.CarrierSpeed >= 1f) return;
        var pawn = p.PlayerPawn.Value;
        if (pawn == null || !pawn.IsValid) return;
        if (pawn.VelocityModifier <= Config.CarrierSpeed) return;
        pawn.VelocityModifier = Config.CarrierSpeed;
        Utilities.SetStateChanged(pawn, "CCSPlayerPawn", "m_flVelocityModifier");
    }

    private readonly HashSet<uint> _ammoBoosted = new();   // weapon entity indexes already doubled
    private float _nextAmmoTick;

    /// "endless": reserve magazines are topped back up to full every half second (you still reload).
    /// "double": each weapon gets twice its normal reserve the first time we see it.
    private void ManageAmmo(float now)
    {
        var mode = Config.AmmoMode.ToLowerInvariant();
        if (mode != "endless" && mode != "double") return;
        if (now < _nextAmmoTick) return;
        _nextAmmoTick = now + 0.5f;

        foreach (var p in Utilities.GetPlayers())
        {
            if (!p.IsValid || !p.PawnIsAlive) continue;
            var ws = p.PlayerPawn.Value?.WeaponServices;
            if (ws == null) continue;

            foreach (var h in ws.MyWeapons)
            {
                var w = h.Value;
                if (w == null || !w.IsValid) continue;
                var max = new CCSWeaponBase(w.Handle).VData?.PrimaryReserveAmmoMax ?? 0;
                if (max <= 0) continue;   // knives, grenades, etc.

                var target = mode == "double" ? max * 2 : max;
                if (mode == "double" && !_ammoBoosted.Add(w.Index)) continue;
                if (w.ReserveAmmo[0] >= target) continue;

                w.ReserveAmmo[0] = target;
                Utilities.SetStateChanged(w, "CBasePlayerWeapon", "m_pReserveAmmo");
            }
        }
    }

    // ───────────────────────── knife-only carrier ─────────────────────────

    private static bool IsKnife(string? name) =>
        name != null && (name.Contains("knife") || name.Contains("bayonet"));

    /// Block (or unblock) shooting with every non-knife weapon the player holds.
    private static void SetGunsBlocked(CCSPlayerController p, bool blocked)
    {
        if (!p.IsValid) return;
        var ws = p.PlayerPawn.Value?.WeaponServices;
        if (ws == null) return;

        var tick = blocked ? Server.TickCount + 10_000_000 : Server.TickCount;
        foreach (var h in ws.MyWeapons)
        {
            var w = h.Value;
            if (w == null || !w.IsValid || IsKnife(w.DesignerName)) continue;
            w.NextPrimaryAttackTick = tick;
            w.NextSecondaryAttackTick = tick;
            Utilities.SetStateChanged(w, "CBasePlayerWeapon", "m_nNextPrimaryAttackTick");
            Utilities.SetStateChanged(w, "CBasePlayerWeapon", "m_nNextSecondaryAttackTick");
        }
    }

    private float _nextKnifeCheck;

    /// Keep flag carriers on their knife (also catches guns bought/picked up while carrying).
    private void EnforceKnife(float now)
    {
        if (!Config.KnifeOnlyCarrier || now < _nextKnifeCheck) return;
        _nextKnifeCheck = now + 0.2f;

        foreach (var flag in _flags.Values)
        {
            if (flag.State != FlagState.Carried) continue;
            var p = Utilities.GetPlayerFromSlot(flag.CarrierSlot);
            if (p == null || !p.IsValid || !p.PawnIsAlive) continue;

            var ws = p.PlayerPawn.Value?.WeaponServices;
            var active = ws?.ActiveWeapon.Value;
            if (active == null || !active.IsValid || IsKnife(active.DesignerName)) continue;

            SetGunsBlocked(p, true);
            SwitchToKnife(p);
        }
    }

    private static void SwitchToKnife(CCSPlayerController p)
    {
        var ws = p.PlayerPawn.Value?.WeaponServices;
        var knife = ws?.MyWeapons.Select(h => h.Value).FirstOrDefault(w => w != null && w.IsValid && IsKnife(w.DesignerName));
        if (knife != null) p.ExecuteClientCommandFromServer($"use {knife.DesignerName}");
        p.ExecuteClientCommand("slot3");
    }

    // ───────────────────────── flag actions ─────────────────────────

    private void Pickup(Flag flag, CCSPlayerController p)
    {
        if (FlagCarriedBy(p.Slot) != null) return; // already carrying one
        var wasDropped = flag.State == FlagState.Dropped;
        flag.State = FlagState.Carried;
        flag.CarrierSlot = p.Slot;

        var owner = flag.Owner;
        var thieves = Other(owner);
        var verb = wasDropped ? "picked up" : "has stolen";

        Announce(owner,
            $"\x02YOUR FLAG HAS BEEN TAKEN!\x01 {TeamColor(thieves)}{p.PlayerName}\x01 {verb} it - stop them!",
            $"YOUR FLAG HAS BEEN TAKEN!\n{p.PlayerName} has it - stop them!", sound: true);
        Announce(thieves,
            $"\x04{p.PlayerName} {verb} the enemy flag!\x01 Cover them home!",
            $"{p.PlayerName} has the enemy flag!\nCover them home!", sound: false, except: p.Slot);
        if (Config.KnifeOnlyCarrier)
        {
            SetGunsBlocked(p, true);
            SwitchToKnife(p);
            p.PrintToChat($"{Prefix}You're carrying the flag - \x04knife only\x01 until you score or drop it" +
                          (Config.DropWithUseKey ? " (\x04E\x01 to drop / pass to a teammate)." : ".") +
                          (Config.CarrierSpeed < 1f ? " You move slower while carrying it." : ""));
            Alert(p, "YOU HAVE THE ENEMY FLAG!\nKnife only - get it back to your base!" +
                     (Config.DropWithUseKey ? "\nPress E to drop it" : ""), sound: true);
        }
        else Alert(p, "YOU HAVE THE ENEMY FLAG!\nGet it back to your base!" +
                      (Config.DropWithUseKey ? "\nPress E to drop it" : ""), sound: true);
    }

    private void Drop(Flag flag, string carrierName)
    {
        var carrier = Utilities.GetPlayerFromSlot(flag.CarrierSlot);
        if (carrier != null && carrier.IsValid && carrier.PawnIsAlive) SetGunsBlocked(carrier, false);

        flag.State = FlagState.Dropped;
        flag.CarrierSlot = -1;
        flag.DroppedAt = Server.CurrentTime;

        var secs = $"{Config.FlagReturnSeconds:0}";
        Announce(flag.Owner,
            $"\x04Your flag was dropped!\x01 Touch it to send it home, or it returns in {secs}s.",
            $"YOUR FLAG WAS DROPPED!\nTouch it to return it ({secs}s)", sound: true);
        Announce(Other(flag.Owner),
            $"\x02{carrierName} dropped the enemy flag!\x01 Pick it up before it returns ({secs}s).",
            $"{carrierName} dropped the enemy flag!\nPick it up!", sound: false);
    }

    private static void ReturnHome(Flag flag)
    {
        flag.State = FlagState.Home;
        flag.CarrierSlot = -1;
        flag.Position = flag.Home;
    }

    private void AnnounceReturn(Flag flag, CCSPlayerController? by)
    {
        var who = by != null ? $"{by.PlayerName} returned it" : "It returned on its own";
        Announce(flag.Owner,
            $"\x04Your flag is back at base.\x01 {who}.",
            "YOUR FLAG IS BACK AT BASE", sound: false);
        Announce(Other(flag.Owner),
            $"The enemy flag was returned to their base. {who}.",
            "The enemy flag was returned", sound: false);
    }

    private void Capture(CCSPlayerController p, Flag stolen)
    {
        _score[p.Team]++;
        ReturnHome(stolen);
        SetGunsBlocked(p, false);
        PushTeamScores();

        var score = $"\x02T {_score[CsTeam.Terrorist]}\x01 - \x0B{_score[CsTeam.CounterTerrorist]} CT";
        var plainScore = $"T {_score[CsTeam.Terrorist]} - {_score[CsTeam.CounterTerrorist]} CT";

        Announce(p.Team,
            $"\x04{p.PlayerName} CAPTURED THE FLAG!\x01 {score}",
            $"{p.PlayerName} CAPTURED THE FLAG!\n{plainScore}", sound: true);
        Announce(stolen.Owner,
            $"\x02The enemy captured your flag.\x01 {score}",
            $"The enemy captured your flag\n{plainScore}", sound: true);

        if (_score[p.Team] >= Config.CaptureLimit)
            EndMatch(p.Team, $"{TeamName(p.Team)} win!");
    }

    private void EndMatch(CsTeam? winner, string message)
    {
        ReleaseAllCarriers();
        _matchOver = true;
        _respawnAt.Clear();
        Server.PrintToChatAll($"{Prefix}\x04{message}\x01 Final: \x02T {_score[CsTeam.Terrorist]}\x01 - \x0B{_score[CsTeam.CounterTerrorist]} CT");

        var rules = Utilities.FindAllEntitiesByDesignerName<CCSGameRulesProxy>("cs_gamerules").FirstOrDefault()?.GameRules;
        var reason = winner switch
        {
            CsTeam.Terrorist => RoundEndReason.TerroristsWin,
            CsTeam.CounterTerrorist => RoundEndReason.CTsWin,
            _ => RoundEndReason.RoundDraw
        };
        rules?.TerminateRound(Config.EndDelaySeconds, reason);
    }

    // ───────────────────────── messages / HUD ─────────────────────────

    /// Chat line + centre-screen alert (+ optional beep) for everyone on one team.
    private void Announce(CsTeam team, string chat, string center, bool sound, int except = -1)
    {
        foreach (var p in Utilities.GetPlayers())
        {
            if (!p.IsValid || p.IsBot || p.IsHLTV || p.Team != team || p.Slot == except) continue;
            p.PrintToChat(Prefix + chat);
            Alert(p, center, sound);
        }
    }

    private void Alert(CCSPlayerController p, string center, bool sound, float hold = AlertHoldSeconds)
    {
        if (!p.IsValid || p.IsBot) return;
        _alertText[p.Slot] = center;
        _alertUntil[p.Slot] = Server.CurrentTime + hold;
        RenderHud(p, Server.CurrentTime);   // show it straight away

        if (sound && !string.IsNullOrEmpty(Config.AlertSound))
        {
            var slot = p.Slot;
            for (var i = 0; i < Math.Max(1, Config.AlertBeeps); i++)
            {
                if (i == 0) Beep(slot);
                else AddTimer(i * Config.BeepGapSeconds, () => Beep(slot));
            }
        }
    }

    private void Beep(int slot)
    {
        var p = Utilities.GetPlayerFromSlot(slot);
        if (p == null || !p.IsValid) return;
        var pawn = p.PlayerPawn.Value;
        if (pawn == null || !pawn.IsValid) return;

        var filter = new RecipientFilter();
        filter.Add(p);
        pawn.EmitSound(Config.AlertSound, filter);
    }

    private void UpdateHud()
    {
        if (_matchOver) return;
        var now = Server.CurrentTime;
        foreach (var p in Utilities.GetPlayers())
            if (p.IsValid && !p.IsBot && !p.IsHLTV) RenderHud(p, now);
    }

    /// Everything centre-screen goes out as ONE message per player, so different
    /// messages never fight over the same spot (that's what caused the flashing).
    private void RenderHud(CCSPlayerController p, float now)
    {
        // top part: an event alert if one is showing, otherwise the flag status
        string? status = null;
        bool isAlert = false;
        if (_alertUntil.TryGetValue(p.Slot, out var until) && now < until && _alertText.TryGetValue(p.Slot, out var a))
        {
            status = a;
            isAlert = true;
        }
        else if (_flags.Count == 2 && _flags.TryGetValue(p.Team, out var own))
        {
            if (!p.PawnIsAlive && _respawnAt.TryGetValue(p.Slot, out var at))
                status = $"Respawning in {Math.Max(1, Math.Ceiling(at - now)):0}...";
            else if (FlagCarriedBy(p.Slot) != null)
                status = own.State == FlagState.Home
                    ? "YOU HAVE THE FLAG!\nRun it home" + (Config.DropWithUseKey ? " - E to drop" : "")
                    : "YOU HAVE THE FLAG!\nYour flag is away - get it back to score";
            else if (own.State == FlagState.Carried)
                status = "YOUR FLAG HAS BEEN TAKEN!";
            else if (own.State == FlagState.Dropped)
                status = $"Your flag is down - touch it to return it ({Math.Max(0, Config.FlagReturnSeconds - (now - own.DroppedAt)):0}s)";
        }

        var style = Config.ShieldTextStyle.ToLowerInvariant();
        if (style == "html")
        {
            var parts = new List<string>();
            if (status != null)
            {
                var color = isAlert ? "#ffd34d" : "#ffffff";
                var lines = Html(status).Split('\n');
                var top = $"<font class='fontSize-m fontWeight-Bold' color='{color}'>{lines[0]}</font>";
                var rest = lines.Skip(1).Select(l => $"<font class='fontSize-s' color='{color}'>{l}</font>");
                parts.Add(string.Join("<br>", new[] { top }.Concat(rest)));
            }
            var shield = ShieldHtml(p, now);
            if (shield != null) parts.Add(shield);
            if (parts.Count > 0) p.PrintToCenterHtml(string.Join("<br>", parts), 1);
            return;
        }

        // plain text styles ("alert" uses CS2's bigger alert text, "center" the normal one)
        var shieldText = ShieldHudLine(p, now);
        var text = status == null ? shieldText : shieldText == null ? status : status + "\n" + shieldText;
        if (text == null) return;
        if (style == "alert") p.PrintToCenterAlert(text);
        else p.PrintToCenter(text);
    }

    private static string Html(string text) =>
        text.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");

    private void PushTeamScores()
    {
        foreach (var team in Utilities.FindAllEntitiesByDesignerName<CCSTeam>("cs_team_manager"))
        {
            var t = (CsTeam)team.TeamNum;
            if (!_score.TryGetValue(t, out var s)) continue;
            team.Score = s;
            Utilities.SetStateChanged(team, "CTeam", "m_iScore");
        }
    }

    // ───────────────────────── commands ─────────────────────────

    [ConsoleCommand("css_ctf_setbase", "Set a team's flag base to where you are standing")]
    [CommandHelper(minArgs: 1, usage: "<t|ct>", whoCanExecute: CommandUsage.CLIENT_ONLY)]
    [RequiresPermissions("@css/root")]
    public void CmdSetBase(CCSPlayerController? player, CommandInfo cmd)
    {
        if (player == null) return;
        var team = cmd.GetArg(1).ToLowerInvariant() switch
        {
            "t" => CsTeam.Terrorist,
            "ct" => CsTeam.CounterTerrorist,
            _ => CsTeam.None
        };
        var pos = PawnPos(player);
        if (team == CsTeam.None || pos == null) { cmd.ReplyToCommand("Usage: !ctf_setbase <t|ct> (while alive)"); return; }

        var file = LoadBases() ?? new BaseFile();
        var arr = new[] { pos.Value.X, pos.Value.Y, pos.Value.Z };
        if (team == CsTeam.Terrorist) file.T = arr; else file.CT = arr;
        SaveBases(file);

        cmd.ReplyToCommand($"[CTF] {TeamName(team)} base saved for {Server.MapName}. Run !ctf_reset to apply.");
    }

    [ConsoleCommand("css_ctf_reset", "Restart the CTF match and respawn flags")]
    [RequiresPermissions("@css/root")]
    public void CmdReset(CCSPlayerController? player, CommandInfo cmd)
    {
        StartMatch();
        cmd.ReplyToCommand("[CTF] Match reset.");
    }

    [ConsoleCommand("css_ctf", "Show CTF score and flag status")]
    public void CmdStatus(CCSPlayerController? player, CommandInfo cmd)
    {
        if (_flags.Count < 2) { cmd.ReplyToCommand("[CTF] Not running on this map (no bases set)."); return; }
        string Describe(Flag f) => f.State switch
        {
            FlagState.Home => "at base",
            FlagState.Dropped => "dropped",
            _ => $"carried by {Utilities.GetPlayerFromSlot(f.CarrierSlot)?.PlayerName ?? "?"}"
        };
        var left = Config.MatchMinutes > 0 ? Math.Max(0, Config.MatchMinutes * 60f - (Server.CurrentTime - _matchStart)) : 0;
        cmd.ReplyToCommand($"[CTF] T {_score[CsTeam.Terrorist]} - {_score[CsTeam.CounterTerrorist]} CT | " +
                           $"T flag {Describe(_flags[CsTeam.Terrorist])}, CT flag {Describe(_flags[CsTeam.CounterTerrorist])}" +
                           (left > 0 ? $" | {(int)left / 60}:{(int)left % 60:00} left" : ""));
    }

    // ───────────────────────── helpers ─────────────────────────

    private Flag? FlagCarriedBy(int slot) =>
        _flags.Values.FirstOrDefault(f => f.State == FlagState.Carried && f.CarrierSlot == slot);

    private static Vector3? PawnPos(CCSPlayerController p)
    {
        var o = p.PlayerPawn.Value?.AbsOrigin;
        return o == null ? null : new Vector3(o.X, o.Y, o.Z);
    }

    private static Vector3? AverageSpawn(CsTeam team)
    {
        var name = team == CsTeam.Terrorist ? "info_player_terrorist" : "info_player_counterterrorist";
        var points = Utilities.FindAllEntitiesByDesignerName<CBaseEntity>(name)
            .Where(e => e.IsValid && e.AbsOrigin != null)
            .Select(e => new Vector3(e.AbsOrigin!.X, e.AbsOrigin.Y, e.AbsOrigin.Z))
            .ToList();
        if (points.Count == 0) return null;
        return points.Aggregate(Vector3.Zero, (a, b) => a + b) / points.Count;
    }

    private string BasesPath => Path.Combine(ModuleDirectory, "bases", $"{Server.MapName}.json");

    private BaseFile? LoadBases()
    {
        try { return File.Exists(BasesPath) ? JsonSerializer.Deserialize<BaseFile>(File.ReadAllText(BasesPath)) : null; }
        catch (Exception e) { Logger.LogError($"[CTF] Bad bases file {BasesPath}: {e.Message}"); return null; }
    }

    private void SaveBases(BaseFile file)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(BasesPath)!);
        File.WriteAllText(BasesPath, JsonSerializer.Serialize(file, new JsonSerializerOptions { WriteIndented = true }));
    }

    private static Vector3? SavedBase(BaseFile? file, CsTeam team)
    {
        var a = team == CsTeam.Terrorist ? file?.T : file?.CT;
        return a is { Length: 3 } ? new Vector3(a[0], a[1], a[2]) : null;
    }

    private static Color TeamRgb(CsTeam t) =>
        t == CsTeam.Terrorist ? Color.FromArgb(255, 235, 60, 45) : Color.FromArgb(255, 60, 130, 255);

    private static CsTeam Other(CsTeam t) => t == CsTeam.Terrorist ? CsTeam.CounterTerrorist : CsTeam.Terrorist;
    private static string TeamName(CsTeam t) => t == CsTeam.Terrorist ? "T" : "CT";
    private static string TeamColor(CsTeam t) => t == CsTeam.Terrorist ? "\x02" : "\x0B";
}
