# CS2 Capture The Flag

A capture-the-flag game mode for Counter-Strike 2 community / private servers, built as a [CounterStrikeSharp](https://github.com/roflmuffin/CounterStrikeSharp) plugin.

**Author:** Jish Josh · **Version:** 0.8.1 · **License:** MIT — free for anyone to use, modify and share (keep the credit)

## How it plays

- **T flag = red, CT flag = blue** (the flags are chickens). They're double size, glow through walls, spin at base, and have a tall pillar of light above them so you can find them across the map.
- Walk over the **enemy** flag to steal it — it floats above your head while you carry it.
- While carrying the flag you're **knife only** and move **15% slower**. Press **E** to drop it and get your guns back — a teammate can then grab it, so you can **pass the flag**. (You can't re-grab it yourself for 2 seconds.)
- Bring it to **your own base while your flag is home** to score a capture.
- Carrier dies → flag drops. Enemies can grab it again; **your team touching your dropped flag sends it home**. Untouched dropped flags return by themselves after 30 seconds.
- First to **3 captures** wins, or the leader when the **15-minute** timer runs out (tie = draw).
- **Halo-style shields:** everyone has 100 health + a 50-point shield (health shows 150). Damage hits the shield first; after 6 seconds without taking damage the shield recharges (health doesn't). A shield bar shows on screen while it's down or recharging.
- **Endless reserve ammo:** spare magazines refill automatically (you still have to reload).
- Players respawn after **8 seconds**, with a countdown on screen. No bomb.
- Each team gets a chat message, an on-screen alert and a triple beep when **their** flag is taken, dropped, returned or captured.

Almost everything above can be changed in the settings file (see below).

## Requirements

1. A CS2 dedicated server (Windows or Linux)
2. [Metamod:Source 2.0](https://www.sourcemm.net/downloads.php?branch=dev) (dev build)
3. [CounterStrikeSharp](https://github.com/roflmuffin/CounterStrikeSharp/releases) — use the **with-runtime** download the first time you install it

## Install

1. Install Metamod and CounterStrikeSharp on your server if you haven't already.
2. Extract this zip into your server's `game/csgo` folder. You should end up with:
   ```
   game/csgo/addons/counterstrikesharp/plugins/CS2CTF/CS2CTF.dll
   game/csgo/cfg/ctf.cfg
   ```
3. Start (or restart) the server. Casual mode works best:
   ```
   +game_type 0 +game_mode 0 +map de_dust2
   ```
   The plugin loads the CTF server settings (`ctf.cfg`) by itself on every map.
4. Check it loaded: type `css_plugins list` in the server console — you should see **CS2 Capture The Flag**.

## Settings

The first time the plugin runs it creates
`game/csgo/addons/counterstrikesharp/configs/plugins/CS2CTF/CS2CTF.json`.
Edit it and restart the server (or change map) to apply. Delete it to get a fresh copy with every option.

| Setting | Default | What it does |
|---|---|---|
| CaptureLimit | 3 | Captures needed to win |
| MatchMinutes | 15 | Time limit, also shown as the round clock (0 = none) |
| RespawnSeconds | 8 | How long dead players wait to respawn |
| PickupRadius | 60 | How close you must be to grab/return a flag (units) |
| CaptureRadius | 90 | How close to your base to score |
| FlagReturnSeconds | 30 | Dropped flag auto-return time |
| FlagModel | models/chicken/chicken.vmdl | Model used as the flag |
| FlagScale | 2.0 | Flag model size (1 = normal) |
| CarryHeight | 82 | How high above the carrier the flag floats |
| SpinFlags | true | Spin flags at base / on the ground |
| Beacon | true | Pillar of light above each flag |
| BeaconHeight | 500 | Pillar height (units) |
| BeaconWidth | 6 | Pillar thickness |
| KnifeOnlyCarrier | true | Flag carrier can only use their knife |
| CarrierSpeed | 0.85 | Flag carrier's speed (1.0 = normal, 0.85 = 15% slower) |
| DropWithUseKey | true | Carrier can press E to drop the flag |
| RepickupCooldownSeconds | 2 | How long before you can grab a flag you just dropped |
| ShieldsEnabled | true | Halo-style recharging shields |
| ShieldAmount | 50 | Shield points on top of 100 health |
| ShieldRechargeDelaySeconds | 6 | Time without damage before the shield starts recharging |
| ShieldRechargePerSecond | 25 | Recharge speed (50 shield = full in 2s) |
| ShowShieldText | true | Show the shield bar on screen |
| ShieldTextStyle | html | `html` (big coloured bar), `alert` (larger plain text) or `center` (plain text) |
| AmmoMode | endless | `endless` (reserve always refills), `double` (twice the normal reserve) or `normal` |
| AlertSound | UIPanorama.popup_accept_match_beep | Sound played with flag alerts (blank = none) |
| AlertBeeps | 3 | How many times the alert sound plays |
| BeepGapSeconds | 0.3 | Gap between beeps |
| EndDelaySeconds | 8 | Pause on the scoreboard after a match ends |

## Placing flag bases

With no setup, each flag sits in the **middle of that team's spawn area**, which works on most maps. To choose the spots yourself, make yourself an admin (`@css/root` in `addons/counterstrikesharp/configs/admins.json`), stand where you want the flag and type in chat:

```
!ctf_setbase t
!ctf_setbase ct
!ctf_reset
```

Bases are saved per map in `plugins/CS2CTF/bases/<mapname>.json`.

## Commands

| Command | Who | |
|---|---|---|
| `!ctf` | anyone | Score, where each flag is, and time left |
| `!ctf_setbase <t\|ct>` | admin | Set a team's base at your feet on this map |
| `!ctf_reset` | admin | Restart the match, flags back home |
| `!ctf_shieldstyle <html\|alert\|center>` | admin | Switch the shield bar style until restart |

## Good maps

Maps where T and CT spawns are far apart with several routes between them: `de_dust2`, `de_inferno`, `de_mirage`, `cs_office`. Small arena workshop maps are great too — set the bases manually.

## Building from source

Needs the [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0):

```
dotnet build CS2CTF.csproj -c Release
```

Output: `bin/Release/net10.0/CS2CTF.dll`
